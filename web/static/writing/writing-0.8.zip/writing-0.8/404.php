<?php
get_header(); ?>
<div class="container mt-4">
  <div class="site-main">
    <div class="main-content p-3 text-center">
      <h1 class="display-1 text-muted py-4">404</h1>
      <p class="display-4 text-muted pb-5">你要找的页面不存在。</p>
    </div>
  </div>
</div>
<?php get_footer(); ?>
