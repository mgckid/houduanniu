<div class="col-lg-4 hidden-md-down">
  <div class="sidebar">
    <?php if ( !dynamic_sidebar('sidebar-1') ) { _e('','lean'); } ?>
  </div>
</div>
